export enum ThreatLevel {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  CRITICAL = 'CRITICAL',
  DEFENSE = 'DEFENSE'
}

export interface Patent {
  rank: number;
  id: string;
  assignee: string;
  title: string;
  alarmingReason: string;
  technicalDetail: string;
  category: string;
  tier: string;
  threatLevel: ThreatLevel;
}

export interface Countermeasure {
  name: string;
  targetThreat?: string;
  description: string;
  effectiveness: string;
  type: 'Physical' | 'Digital' | 'Behavioral' | 'Legal';
}

export interface AnalysisResult {
  analysis: string;
  recommendedActions: string[];
}