import { Patent } from "../types";

// Offline service replacement for Gemini AI

export const analyzePatentRisk = async (patent: Patent): Promise<string> => {
  // Simulate processing delay
  await new Promise(resolve => setTimeout(resolve, 1000));

  return `[OFFLINE MODE - LOCAL HEURISTIC ANALYSIS]

TARGET: ${patent.id}
ASSIGNEE: ${patent.assignee}

THREAT VECTOR ANALYSIS:
The identified patent describes a system capable of ${patent.alarmingReason.toLowerCase()}. 
This technology leverages ${patent.technicalDetail} to bypass traditional privacy boundaries.

PRIVACY IMPACT:
- Surveillance capability: HIGH
- Consent requirement: BYPASSED
- Detection difficulty: HIGH

SUGGESTED DEFENSIVE PROTOCOL:
1. Awareness: Recognize the presence of ${patent.category} technologies.
2. Signal Disruption: Employ signal jamming or Faraday shielding where applicable.
3. Obfuscation: Introduce noise into the data stream (e.g., thermal masking, gait randomization, or digital exhaust spoofing).

CONCLUSION:
This technology represents a tangible threat to civil liberties. Proceed with caution.`;
};

export const generateTacticalAdvice = async (query: string): Promise<string> => {
  // Simulate processing delay
  await new Promise(resolve => setTimeout(resolve, 800));

  const responses = [
    "Deploying counter-surveillance measures is recommended. Ensure all sensitive electronics are shielded.",
    "Signal interception risk detected. Recommend strictly wired communications for sensitive data.",
    "Pattern-of-life analysis is a primary vector. Randomize daily routines to disrupt predictive modeling.",
    "Biometric harvesting is ubiquitous. Use IR-blocking eyewear and acoustic masking where possible.",
    "The most effective defense is data minimization. Do not generate the data point if it can be avoided.",
    "Use low-tech solutions for high-tech threats. Physical barriers often outperform digital firewalls against RF sensing.",
    "Assume all unencrypted channels are compromised. Utilize one-time pads for critical communications."
  ];

  // Simple deterministic selection based on query length to fake "analysis" consistency, or random.
  // Using random for variety as requested in a 'chat' context often.
  const response = responses[Math.floor(Math.random() * responses.length)];

  return `[TACTICAL ADVISOR - OFFLINE]

QUERY: "${query.toUpperCase()}"

ANALYSIS:
Input parameters suggest a concern regarding surveillance exposure.

TACTICAL RECOMMENDATION:
${response}

Standard Protocol:
1. Trust no digital transmission.
2. Verify physical security.
3. Maintain operational security (OPSEC) at all times.`;
};