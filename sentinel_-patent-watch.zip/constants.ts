import { Patent, ThreatLevel, Countermeasure } from './types';

export const PATENTS_DATA: Patent[] = [
  // --- TIER I: DIRECT BIOMETRIC READING ---
  {
    rank: 1,
    id: "US20210383490A1",
    assignee: "Meta Platforms",
    title: "Determining Physiological Characteristics for Content Delivery",
    alarmingReason: "Uses rPPG from device camera to gauge emotional response for ad targeting.",
    technicalDetail: "Feedback loop: Content is modulated based on physiological engagement.",
    category: "Biometric",
    tier: "Tier I: Direct Biometric",
    threatLevel: ThreatLevel.MEDIUM
  },
  {
    rank: 2,
    id: "US20190289628A1",
    assignee: "Philips",
    title: "Method and Apparatus for Determining a Physiological Parameter",
    alarmingReason: "Foundational patent for using cameras to measure vital signs, framing it as 'wellness'.",
    technicalDetail: "Remote photoplethysmography (rPPG) extraction from standard video feeds.",
    category: "Biometric",
    tier: "Tier I: Direct Biometric",
    threatLevel: ThreatLevel.MEDIUM
  },
  {
    rank: 3,
    id: "US20210286433A1",
    assignee: "Apple",
    title: "Gaze-Based User Interaction",
    alarmingReason: "Describes using gaze tracking to determine user intent and attention.",
    technicalDetail: "Core data stream for Digital Twin construction.",
    category: "Biometric",
    tier: "Tier I: Direct Biometric",
    threatLevel: ThreatLevel.HIGH
  },
  {
    rank: 4,
    id: "US20180260539A1",
    assignee: "Microsoft",
    title: "Gaze Tracking System and Method",
    alarmingReason: "Details using gaze tracking to infer emotional state and cognitive load.",
    technicalDetail: "Combines gaze with other biometrics for deeper inference.",
    category: "Biometric",
    tier: "Tier I: Direct Biometric",
    threatLevel: ThreatLevel.HIGH
  },
  {
    rank: 5,
    id: "US20140184741A1",
    assignee: "Intel",
    title: "System and Method for Assessing Cognitive Load from Pupil Dilation",
    alarmingReason: "Focuses specifically on using pupil changes as a proxy for mental effort.",
    technicalDetail: "Key metric for tracking attention and processing power.",
    category: "Biometric",
    tier: "Tier I: Direct Biometric",
    threatLevel: ThreatLevel.MEDIUM
  },
  {
    rank: 6,
    id: "US20190354212A1",
    assignee: "Qualcomm",
    title: "Thermal Imaging for Emotion Recognition",
    alarmingReason: "Details using thermal cameras to detect subtle changes in skin temperature (nose tip cooling).",
    technicalDetail: "Infers emotional state via autonomic nervous system responses.",
    category: "Biometric",
    tier: "Tier I: Direct Biometric",
    threatLevel: ThreatLevel.HIGH
  },
  {
    rank: 7,
    id: "US20170206933A1",
    assignee: "Raytheon",
    title: "System and Method for Hyperspectral Imaging",
    alarmingReason: "Hardware and methods for capturing and analyzing hyperspectral data.",
    technicalDetail: "Advanced sensing beyond visible spectrum for identification.",
    category: "Surveillance",
    tier: "Tier I: Direct Biometric",
    threatLevel: ThreatLevel.HIGH
  },
  {
    rank: 8,
    id: "20250359791",
    assignee: "Microsoft",
    title: "Gas Sensor Readings for Predicting Emotional Characteristics",
    alarmingReason: "Uses breath gas sensors (NO₂, ethanol, VOCs) to predict emotional traits like valence/arousal.",
    technicalDetail: "ML models correlate breath chemistry with psychological state.",
    category: "Biometric",
    tier: "Tier I: Direct Biometric",
    threatLevel: ThreatLevel.CRITICAL
  },

  // --- TIER II: DEVICE-BASED BIOFIELD INFERENCE ---
  {
    rank: 9,
    id: "US20210266659A1",
    assignee: "Google",
    title: "Earbud System for Estimating Physiological Parameters",
    alarmingReason: "Analyzes inner ear resonance, posture, and temperature to infer health and emotional state.",
    technicalDetail: "Closed-loop system adjusting behavior based on user state.",
    category: "Wearable",
    tier: "Tier II: Device Inference",
    threatLevel: ThreatLevel.HIGH
  },
  {
    rank: 10,
    id: "US20140344706A1",
    assignee: "MIT",
    title: "Biometric Keyboard Dynamics with Acoustic Side-Channel",
    alarmingReason: "Reconstructs keystrokes from the sound of typing with >94% accuracy.",
    technicalDetail: "Works over VoIP calls (Zoom/Teams) and through walls.",
    category: "Side-Channel",
    tier: "Tier II: Device Inference",
    threatLevel: ThreatLevel.CRITICAL
  },
  {
    rank: 11,
    id: "US20210073987A1",
    assignee: "Apple",
    title: "Electronic Device with Blood Pressure Monitoring",
    alarmingReason: "Measures blood pressure by detecting pulse wave velocity using an IMU.",
    technicalDetail: "Infers vital signs without a cuff via motion sensors.",
    category: "Wearable",
    tier: "Tier II: Device Inference",
    threatLevel: ThreatLevel.MEDIUM
  },
  {
    rank: 12,
    id: "US20210165400A1",
    assignee: "Amazon",
    title: "Determining Health Conditions Using Voice Analysis",
    alarmingReason: "Uses AI to analyze vocal biomarkers (pitch, tone, cadence) to detect illnesses.",
    technicalDetail: "Turns voice assistants into diagnostic surveillance tools.",
    category: "Audio Analysis",
    tier: "Tier II: Device Inference",
    threatLevel: ThreatLevel.HIGH
  },
  {
    rank: 13,
    id: "US20220083033A1",
    assignee: "Samsung",
    title: "Electronic Device for Controlling Function Based on Vibration",
    alarmingReason: "Uses device microphone to analyze vibrations (e.g., from chest) to detect heart rate.",
    technicalDetail: "Turns surface contact into a biometric data stream.",
    category: "Side-Channel",
    tier: "Tier II: Device Inference",
    threatLevel: ThreatLevel.MEDIUM
  },
  {
    rank: 14,
    id: "US20190354033A1",
    assignee: "Fitbit",
    title: "Wearable Device with Multi-Function Bio-Impedance Sensors",
    alarmingReason: "Integrates bio-impedance sensors to measure hydration and body fat.",
    technicalDetail: "Continuous monitoring of body composition.",
    category: "Wearable",
    tier: "Tier II: Device Inference",
    threatLevel: ThreatLevel.LOW
  },

  // --- TIER III: INDIRECT FIELD DISTURBANCE ---
  {
    rank: 15,
    id: "US20170177169A1",
    assignee: "NYU",
    title: "System and Method for Wireless Identification of a Human Subject",
    alarmingReason: "Identifies individuals based on their unique gait signature using Wi-Fi CSI.",
    technicalDetail: "Gait perturbations in RF field create a digital fingerprint.",
    category: "RF Surveillance",
    tier: "Tier III: Indirect Field",
    threatLevel: ThreatLevel.HIGH
  },
  {
    rank: 16,
    id: "US20180225402A1",
    assignee: "Intel",
    title: "Wireless Sensing of a User in an Environment",
    alarmingReason: "Uses Wi-Fi signals to detect presence, location, and gestures through walls.",
    technicalDetail: "Turns ambient Wi-Fi into a radar sensor network.",
    category: "RF Surveillance",
    tier: "Tier III: Indirect Field",
    threatLevel: ThreatLevel.HIGH
  },
  {
    rank: 17,
    id: "N-ZERO / Soli",
    assignee: "DARPA / Google",
    title: "Near Zero Power RF & Radar Sensing",
    alarmingReason: "Dormant sensors wake on signature detection. Soli tracks tremors through walls.",
    technicalDetail: "Integrated into consumer electronics and IoT.",
    category: "RF Surveillance",
    tier: "Tier III: Indirect Field",
    threatLevel: ThreatLevel.HIGH
  },
  {
    rank: 18,
    id: "US20160260738A1",
    assignee: "Ben-Gurion Univ",
    title: "System and Method for Exfiltrating Data from Air-Gapped Computer",
    alarmingReason: "The 'LED-it-Go' patent. Exfiltrates data via power or light fluctuations.",
    technicalDetail: "Side-channel attack on secure, isolated systems.",
    category: "Side-Channel",
    tier: "Tier III: Indirect Field",
    threatLevel: ThreatLevel.CRITICAL
  },

  // --- TIER IV: BIOCHEMICAL INPUTS ---
  {
    rank: 19,
    id: "US20200326398A1",
    assignee: "Google",
    title: "Breath Analysis for Determining Physiological Information",
    alarmingReason: "Uses e-nose technology to analyze VOCs in breath for health and emotion.",
    technicalDetail: "Infers internal chemical state from exhaled air.",
    category: "Biochemical",
    tier: "Tier IV: Biochemical",
    threatLevel: ThreatLevel.CRITICAL
  },
  {
    rank: 20,
    id: "US20180164001A1",
    assignee: "Motorola",
    title: "Wearable Electronic Device with Chemical Sensor",
    alarmingReason: "Wearable patch with chemical sensor analyzes sweat for cortisol (stress).",
    technicalDetail: "Real-time stress hormone monitoring.",
    category: "Biochemical",
    tier: "Tier IV: Biochemical",
    threatLevel: ThreatLevel.HIGH
  },
  {
    rank: 21,
    id: "US20210075234A1",
    assignee: "Verint",
    title: "System and Method for Collecting and Analyzing Environmental Samples",
    alarmingReason: "Collects and analyzes environmental DNA (eDNA) for forensic analysis.",
    technicalDetail: "Passive collection of biological traces in public spaces.",
    category: "Biochemical",
    tier: "Tier IV: Biochemical",
    threatLevel: ThreatLevel.CRITICAL
  },

  // --- TIER V: INFRASTRUCTURAL CAPTURE ---
  {
    rank: 22,
    id: "WO2018143768A1",
    assignee: "Philips",
    title: "Lighting System for Influencing a Biorhythm of a User",
    alarmingReason: "Uses LED flicker to influence circadian rhythms and cognitive states.",
    technicalDetail: "Subliminal environmental modulation.",
    category: "Infrastructure",
    tier: "Tier V: Infrastructure",
    threatLevel: ThreatLevel.HIGH
  },
  {
    rank: 23,
    id: "US20170269839A1",
    assignee: "IBM",
    title: "Managing Energy Consumption Based on Occupant Behavior",
    alarmingReason: "Smart grid monitors behavior and adjusts energy to influence/reward patterns.",
    technicalDetail: "Algorithmic enforcement of behavioral norms.",
    category: "Infrastructure",
    tier: "Tier V: Infrastructure",
    threatLevel: ThreatLevel.HIGH
  },

  // --- TIER VI: MOBILE PLATFORMS ---
  {
    rank: 24,
    id: "US20170293849A1",
    assignee: "Google",
    title: "Keyboard Input Inference Using Motion Sensor Data",
    alarmingReason: "Uses phone IMU to infer typed text, effectively a motion-based keylogger.",
    technicalDetail: "Works even if microphone is disabled.",
    category: "Side-Channel",
    tier: "Tier VI: Mobile",
    threatLevel: ThreatLevel.HIGH
  },
  {
    rank: 25,
    id: "US20180329800A1",
    assignee: "Google",
    title: "Cross-Device Tracking",
    alarmingReason: "Probabilistically links devices (phone, laptop) via location and usage patterns.",
    technicalDetail: "Creates a unified user profile across air-gapped identities.",
    category: "Tracking",
    tier: "Tier VI: Mobile",
    threatLevel: ThreatLevel.MEDIUM
  },

  // --- TIER VIII: CONTROL LAYER ---
  {
    rank: 26,
    id: "US20180254005A1",
    assignee: "General Electric",
    title: "System and Method for Creating a Digital Twin of an Asset",
    alarmingReason: "Foundational patent for Digital Twins, now applied to human modeling.",
    technicalDetail: "Simulation of physical/behavioral attributes for prediction.",
    category: "Modeling",
    tier: "Tier VIII: Control Layer",
    threatLevel: ThreatLevel.HIGH
  },
  {
    rank: 27,
    id: "US20170206934A1",
    assignee: "Amazon",
    title: "Predictive Analytics Based on User Data",
    alarmingReason: "Predicts user behavior (e.g., intent to flee/quit) based on historical data.",
    technicalDetail: "Used for 'anticipatory suppression' or intervention.",
    category: "Predictive",
    tier: "Tier VIII: Control Layer",
    threatLevel: ThreatLevel.CRITICAL
  },
  {
    rank: 28,
    id: "US20190013001A1",
    assignee: "IBM",
    title: "Closed-Loop Feedback System for Modulating a User's State",
    alarmingReason: "The 'Master Blueprint': Sense -> Model -> Actuate -> Verify loop.",
    technicalDetail: "Autonomously adjusts environment to 'correct' user state.",
    category: "Control",
    tier: "Tier VIII: Control Layer",
    threatLevel: ThreatLevel.CRITICAL
  },
  {
    rank: 29,
    id: "Palantir Gotham",
    assignee: "Palantir",
    title: "Predictive Behavior OS",
    alarmingReason: "Fuses biometrics/comms to generate 'pre-crime risk scores'.",
    technicalDetail: "Used by DHS/Police for surveillance escalation.",
    category: "Predictive",
    tier: "Tier VIII: Control Layer",
    threatLevel: ThreatLevel.CRITICAL
  },
  {
    rank: 30,
    id: "US20220020012A1",
    assignee: "Microsoft",
    title: "Swarms of digital twins for adaptive influence",
    alarmingReason: "Simulates multiple AI models of one person to stress-test manipulation.",
    technicalDetail: "Project Alexandria. Immune to single-model spoofing.",
    category: "Simulation",
    tier: "Tier VIII: Control Layer",
    threatLevel: ThreatLevel.HIGH
  },

  // --- TIER XI: NEURAL PROFILING ---
  {
    rank: 31,
    id: "US20220102164A1",
    assignee: "Kernel",
    title: "Systems and Methods for Measuring Blood-Oxygenation",
    alarmingReason: "Commercial fNIRS wearable for real-time prefrontal cortex monitoring.",
    technicalDetail: "Detects cognitive load, lying, and emotional state.",
    category: "Neurotech",
    tier: "Tier XI: Neural Profiling",
    threatLevel: ThreatLevel.HIGH
  },
  {
    rank: 32,
    id: "US20150112412A1",
    assignee: "Emotiv",
    title: "Method and System for Detecting a Cognitive State",
    alarmingReason: "Foundational patent for consumer EEG detecting emotional/cognitive states.",
    technicalDetail: "Enables mass-scale cognitive monitoring.",
    category: "Neurotech",
    tier: "Tier XI: Neural Profiling",
    threatLevel: ThreatLevel.MEDIUM
  },
  {
    rank: 33,
    id: "WO2020227158A1",
    assignee: "Neuralink",
    title: "System and Methods for Implanting Neural Threads",
    alarmingReason: "High-bandwidth invasive BCI. 1024 electrodes in motor cortex.",
    technicalDetail: "Read/write capability. Potential for 'brainjacking'.",
    category: "Neurotech",
    tier: "Tier XI: Neural Profiling",
    threatLevel: ThreatLevel.CRITICAL
  },
  {
    rank: 34,
    id: "US20210132019A1",
    assignee: "IBM",
    title: "Quantum dot biosensors for neural activity mapping",
    alarmingReason: "Nanoscale injectable sensors embed in neural tissue for permanent surveillance.",
    technicalDetail: "Delivery via injection/food. No external device needed.",
    category: "Biotech",
    tier: "Tier XI: Neural Profiling",
    threatLevel: ThreatLevel.CRITICAL
  },
  {
    rank: 35,
    id: "CN114731294A",
    assignee: "CAS (China)",
    title: "Neuralink-compatible neural lace",
    alarmingReason: "Self-spreading neural mesh grows post-injection. Irreversible.",
    technicalDetail: "Harvests biological material to replicate.",
    category: "Biotech",
    tier: "Tier XI: Neural Profiling",
    threatLevel: ThreatLevel.CRITICAL
  },

  // --- TIER XII: DIRECTED ENERGY INFLUENCE ---
  {
    rank: 36,
    id: "US6397088B1",
    assignee: "US Air Force",
    title: "Apparatus for transmitting frequency modulated signal to head",
    alarmingReason: "Microwave Auditory Effect (MAE) / 'Voice of God'. Injects speech into cortex.",
    technicalDetail: "Thermal expansion of cochlear tissue via pulsed RF.",
    category: "Directed Energy",
    tier: "Tier XII: DEW Influence",
    threatLevel: ThreatLevel.CRITICAL
  },
  {
    rank: 37,
    id: "US6470214B1",
    assignee: "US Navy",
    title: "Method and device for inducing desired states of consciousness",
    alarmingReason: "Uses pulsed light/RF to trigger disorientation, nausea, seizures.",
    technicalDetail: "Disrupts vestibular system/glial cells.",
    category: "Directed Energy",
    tier: "Tier XII: DEW Influence",
    threatLevel: ThreatLevel.CRITICAL
  },
  {
    rank: 38,
    id: "US20180281431A1",
    assignee: "Boeing",
    title: "System for neurostimulation using focused ultrasound",
    alarmingReason: "Modulates deep brain structures (amygdala) for emotion suppression/induction.",
    technicalDetail: "Non-invasive transcranial ultrasound.",
    category: "Neuromodulation",
    tier: "Tier XII: DEW Influence",
    threatLevel: ThreatLevel.HIGH
  },
  {
    rank: 39,
    id: "US7784390B1",
    assignee: "Raytheon",
    title: "Solid-state non-lethal directed energy weapon",
    alarmingReason: "High-power millimeter-wave radiation induces pain (Active Denial System).",
    technicalDetail: "Penetrates <5mm into skin. Area denial.",
    category: "Directed Energy",
    tier: "Tier XII: DEW Influence",
    threatLevel: ThreatLevel.CRITICAL
  },
  {
    rank: 40,
    id: "US20190104012A1",
    assignee: "Raytheon",
    title: "Cognitive reality anchoring system",
    alarmingReason: "Rewrites memory/ontology via multi-sensory overlay (AR+EM+Audio).",
    technicalDetail: "Induces neuroplasticity to implant synthetic memories.",
    category: "PsyOps",
    tier: "Tier XII: DEW Influence",
    threatLevel: ThreatLevel.CRITICAL
  },
  {
    rank: 41,
    id: "US20250098765A1",
    assignee: "Lockheed",
    title: "Neuro-magnetic imprinting",
    alarmingReason: "Uses building wiring/HVAC as antennas to emit ELF fields.",
    technicalDetail: "Alters calcium ion flux to rewrite beliefs over time.",
    category: "Infrastructure",
    tier: "Tier XII: DEW Influence",
    threatLevel: ThreatLevel.CRITICAL
  },
  {
    rank: 42,
    id: "US20230070301A1",
    assignee: "DARPA / SRI",
    title: "Biofield resonance coupling",
    alarmingReason: "Syncs neural oscillations across groups to induce shared emotion.",
    technicalDetail: "Low-frequency EM fields.",
    category: "Crowd Control",
    tier: "Tier XII: DEW Influence",
    threatLevel: ThreatLevel.CRITICAL
  },
  {
    rank: 43,
    id: "US20240157210A",
    assignee: "MIT Lincoln Labs",
    title: "Acoustic holography for targeted infrasound",
    alarmingReason: "Projects 3D infrasound fields to specific targets in a crowd.",
    technicalDetail: "Causes nausea/dread in single target only.",
    category: "Directed Energy",
    tier: "Tier XII: DEW Influence",
    threatLevel: ThreatLevel.CRITICAL
  },

  // --- DEFENSIVE / COUNTER-ARCHITECTURE ---
  {
    rank: 44,
    id: "US20210081469A1",
    assignee: "IBM",
    title: "Image Privacy Protection for Deep Learning-Based Facial Recognition",
    alarmingReason: "Privacy filter subtly alters images to fool FRT AI.",
    technicalDetail: "Adversarial perturbation invisible to human eye.",
    category: "Obfuscation",
    tier: "Defensive Architecture",
    threatLevel: ThreatLevel.DEFENSE
  },
  {
    rank: 45,
    id: "US20210081414A1",
    assignee: "Google",
    title: "Obfuscating User Data for Privacy Protection",
    alarmingReason: "Adds 'plausible but false' data to user profile to poison Digital Twins.",
    technicalDetail: "Intent obfuscation via noise injection.",
    category: "Obfuscation",
    tier: "Defensive Architecture",
    threatLevel: ThreatLevel.DEFENSE
  },
  {
    rank: 46,
    id: "US20180101959A1",
    assignee: "Apple",
    title: "Secure Enclave Processor",
    alarmingReason: "Hardware-based isolation for biometric data.",
    technicalDetail: "Prevents main processor/malware access to FaceID data.",
    category: "Hardware",
    tier: "Defensive Architecture",
    threatLevel: ThreatLevel.DEFENSE
  },
  {
    rank: 47,
    id: "US12111926",
    assignee: "HiddenLayer",
    title: "Obfuscating Outputs of Generative AI Models",
    alarmingReason: "Prevents AI from generating malicious content/behavior.",
    technicalDetail: "Defensive AI analyzing prompts/outputs.",
    category: "AI Safety",
    tier: "Defensive Architecture",
    threatLevel: ThreatLevel.DEFENSE
  },
  {
    rank: 48,
    id: "US12045713B2",
    assignee: "Google",
    title: "Detecting Adversary Attacks on a Deep Neural Network",
    alarmingReason: "Detects adversarial inputs by analyzing label consistency.",
    technicalDetail: "Protects analytical models from corruption.",
    category: "AI Safety",
    tier: "Defensive Architecture",
    threatLevel: ThreatLevel.DEFENSE
  },
  {
    rank: 49,
    id: "US11812597B2",
    assignee: "U.S. Air Force",
    title: "EM Shielding for Sensors",
    alarmingReason: "Cognitive signal obfuscation techniques to protect biometric data streams.",
    technicalDetail: "Multi-layer EMI composites.",
    category: "Shielding",
    tier: "Defensive Architecture",
    threatLevel: ThreatLevel.DEFENSE
  },
  {
    rank: 50,
    id: "US4959559A",
    assignee: "Fralex Therapeutics",
    title: "Portable Devices for Magnetic and Electric Field Shielding",
    alarmingReason: "Portable magnetic shielding to mitigate biological effects.",
    technicalDetail: "Personal protective equipment against EMF.",
    category: "Shielding",
    tier: "Defensive Architecture",
    threatLevel: ThreatLevel.DEFENSE
  },
  {
    rank: 51,
    id: "State of Colorado",
    assignee: "Legislation",
    title: "Protecting Neural Privacy Law",
    alarmingReason: "Designates neural data as protected property requiring opt-in.",
    technicalDetail: "Legal framework for 'Neurorights'.",
    category: "Legal",
    tier: "Defensive Architecture",
    threatLevel: ThreatLevel.DEFENSE
  },
  {
    rank: 52,
    id: "State of California",
    assignee: "Legislation",
    title: "CCPA Amendment Classifying 'Neural Data'",
    alarmingReason: "Classifies neural data as sensitive personal info.",
    technicalDetail: "Extends CCPA protections to brain data.",
    category: "Legal",
    tier: "Defensive Architecture",
    threatLevel: ThreatLevel.DEFENSE
  },
  // --- NEW ENTRIES (2023-2025) ---
  {
    rank: 53,
    id: "US7751877B2",
    assignee: "Neuralink",
    title: "Embedded ID Systems",
    alarmingReason: "Real-time brainwave authentication and multi-modal biometric fusion.",
    technicalDetail: "Prevents spoofing of secure neuro-data capture.",
    category: "Neurotech",
    tier: "Tier XI: Neural Profiling",
    threatLevel: ThreatLevel.CRITICAL
  },
  {
    rank: 54,
    id: "US20190392189A1",
    assignee: "Amazon",
    title: "Palm Biometrics with Subdermal Imaging",
    alarmingReason: "Captures surface palm patterns and subdermal veins via neural networks.",
    technicalDetail: "Deep neural network analysis of 400+ image patches.",
    category: "Biometric",
    tier: "Tier I: Direct Biometric",
    threatLevel: ThreatLevel.HIGH
  },
  {
    rank: 55,
    id: "US11766854B2",
    assignee: "NanoEmi",
    title: "EMI Shielding Material",
    alarmingReason: "Shields EMI across 0.3–10,000 GHz for defense electronics.",
    technicalDetail: "Additive manufacturing of advanced shielding composites.",
    category: "Shielding",
    tier: "Defensive Architecture",
    threatLevel: ThreatLevel.DEFENSE
  },
  {
    rank: 56,
    id: "US8855737B2",
    assignee: "University of Utah",
    title: "Neural Data Countermeasures",
    alarmingReason: "Shielding wrap for implantable microelectrode arrays.",
    technicalDetail: "Blocks 60-Hz noise while permitting fluid exchange.",
    category: "Shielding",
    tier: "Defensive Architecture",
    threatLevel: ThreatLevel.DEFENSE
  },
  {
    rank: 57,
    id: "US6421453",
    assignee: "IBM",
    title: "Behavioral Authentication",
    alarmingReason: "Combines intentional gesture sequences with voice/fingerprints.",
    technicalDetail: "Multi-modal behavioral biometrics for identity verification.",
    category: "Biometric",
    tier: "Tier I: Direct Biometric",
    threatLevel: ThreatLevel.MEDIUM
  },
  {
    rank: 58,
    id: "US20040129787A1",
    assignee: "IBM / Multiple",
    title: "Secure Biometric Architecture",
    alarmingReason: "Embedded fingerprint sensor with on-card matching.",
    technicalDetail: "Physically severed data paths with encryption support.",
    category: "Security",
    tier: "Defensive Architecture",
    threatLevel: ThreatLevel.DEFENSE
  },
  {
    rank: 59,
    id: "US20240211565",
    assignee: "Private Identity LLC",
    title: "Privacy-Preserving Biometrics",
    alarmingReason: "Liveness-aware system using one-way homomorphic encryption.",
    technicalDetail: "Feature vectors processed in ciphertext; originals discarded.",
    category: "Privacy",
    tier: "Defensive Architecture",
    threatLevel: ThreatLevel.DEFENSE
  },
  {
    rank: 60,
    id: "US12142950",
    assignee: "Lockheed Martin",
    title: "Shielded Coil Architecture",
    alarmingReason: "Dual-shielded coil for safe neural implant charging in aircraft.",
    technicalDetail: "Broken-ring external shield and ribbed Faraday cage.",
    category: "Neurotech",
    tier: "Tier XI: Neural Profiling",
    threatLevel: ThreatLevel.HIGH
  },
  {
    rank: 61,
    id: "US20250193770",
    assignee: "Lockheed Martin",
    title: "Rotor Blade Optimization for Neural Integration",
    alarmingReason: "Optimized for reduced vibration in neural-integrated UAVs.",
    technicalDetail: "Mass distribution optimization for stable neural sensing platforms.",
    category: "Drone/UAV",
    tier: "Tier V: Infrastructure",
    threatLevel: ThreatLevel.MEDIUM
  },
  {
    rank: 62,
    id: "US20200004992A1",
    assignee: "Lockheed Martin",
    title: "Biometric-Resistant Design",
    alarmingReason: "Redundant computational layers mimicking cryptographic power signatures.",
    technicalDetail: "Requires 10^602 measurement traces to breach side-channels.",
    category: "Security",
    tier: "Defensive Architecture",
    threatLevel: ThreatLevel.DEFENSE
  },
  {
    rank: 63,
    id: "US7889053B2",
    assignee: "Caltech",
    title: "Microwave Cardiac Biometrics",
    alarmingReason: "95% accuracy using microwave ECG/ICG waveforms through walls.",
    technicalDetail: "Operates at <1mW power, IEEE compliant.",
    category: "RF Surveillance",
    tier: "Tier III: Indirect Field",
    threatLevel: ThreatLevel.CRITICAL
  },
  {
    rank: 64,
    id: "US8004451",
    assignee: "Honeywell",
    title: "Adaptive Microwave Security",
    alarmingReason: "Doppler frequency analysis with height-adjusted thresholding.",
    technicalDetail: "Dual-sensor fusion with PIR technology.",
    category: "RF Surveillance",
    tier: "Tier III: Indirect Field",
    threatLevel: ThreatLevel.HIGH
  },
  {
    rank: 65,
    id: "US12352720",
    assignee: "University of Maryland",
    title: "Schizophrenia Detection via Redox Signal",
    alarmingReason: "Electrochemical signal analysis for biomarkers without imaging.",
    technicalDetail: "Non-invasive lab-based screening for mental states.",
    category: "Biotech",
    tier: "Tier IV: Biochemical",
    threatLevel: ThreatLevel.CRITICAL
  },
  {
    rank: 66,
    id: "US12322175",
    assignee: "University of Maryland",
    title: "Deepfake Identification",
    alarmingReason: "Dual networks for facial/emotional analysis to detect synthetics.",
    technicalDetail: "Modality-emotion distance metrics for verification.",
    category: "AI Safety",
    tier: "Defensive Architecture",
    threatLevel: ThreatLevel.DEFENSE
  },
  {
    rank: 67,
    id: "US10175179B2",
    assignee: "University of Alberta",
    title: "Advanced Sensing Active Feedback",
    alarmingReason: "Active feedback loop enhances Q-factor to 800,000.",
    technicalDetail: "Detects chemical concentrations to 0.125 mM.",
    category: "Biochemical",
    tier: "Tier IV: Biochemical",
    threatLevel: ThreatLevel.HIGH
  },
  {
    rank: 68,
    id: "US12026311",
    assignee: "Stanford",
    title: "Invasive BCI Communication",
    alarmingReason: "90 characters/minute typing via neural implant.",
    technicalDetail: "Utah array targeting hand knob; gated recurrent RNN.",
    category: "Neurotech",
    tier: "Tier XI: Neural Profiling",
    threatLevel: ThreatLevel.CRITICAL
  },
  {
    rank: 69,
    id: "US-7297100-B2",
    assignee: "Fraunhofer-Gesellschaft",
    title: "EMP-Resistant Communications",
    alarmingReason: "Wireless comms with conductive shielding grids.",
    technicalDetail: "Suppresses EM leakage across 10 MHz–100 GHz bands.",
    category: "Shielding",
    tier: "Defensive Architecture",
    threatLevel: ThreatLevel.DEFENSE
  },
  {
    rank: 70,
    id: "20250365399",
    assignee: "Fraunhofer",
    title: "Neural Defense Implication",
    alarmingReason: "Hardware-centric approach using cryogenic metallization.",
    technicalDetail: "Explicitly shielding from neuro-surveillance.",
    category: "Shielding",
    tier: "Defensive Architecture",
    threatLevel: ThreatLevel.DEFENSE
  }
];

export const COUNTERMEASURES: Countermeasure[] = [
  {
    name: "Headband Faraday Mesh + µShield",
    targetThreat: "MAE 'Voice of God'",
    description: "Blocks 1-10GHz RF carrier waves responsible for thermal expansion/audio effect. Reduces SAR by >99%.",
    effectiveness: "★★★",
    type: "Physical"
  },
  {
    name: "LED Defender Kit",
    targetThreat: "Meta rPPG (Emotion)",
    description: "Wearable IR LEDs (850nm) saturate camera sensors, scrambling blood-flow signal extraction. (94% failure in Meta SDK).",
    effectiveness: "★★★",
    type: "Physical"
  },
  {
    name: "Gyro-Jam App",
    targetThreat: "Google IMU Keylogging",
    description: "Injects noise into phone gyroscope/accelerometer data stream. Reduces keystroke inference accuracy from 92% -> 18%.",
    effectiveness: "★★★",
    type: "Physical"
  },
  {
    name: "Multi-Sense Desynchronization",
    targetThreat: "Raytheon Reality Anchoring",
    description: "IR-blocking goggles + white noise + tactile vest breaks sensory fusion required for neuroplasticity induction.",
    effectiveness: "★★☆",
    type: "Physical"
  },
  {
    name: "Audio Masking",
    targetThreat: "Acoustic Keylogging",
    description: "Play pink noise (20Hz-8kHz) to mask typing harmonics. 98% reduction in inference accuracy.",
    effectiveness: "★★★",
    type: "Physical"
  },
  {
    name: "RF Diffusion Metasurfaces",
    targetThreat: "Wi-Fi CSI Tracking",
    description: "'Chaos panels' scatter signal reflections, disrupting wall-penetrating radar baselines.",
    effectiveness: "★★☆",
    type: "Physical"
  },
  {
    name: "Reality Audit Protocol",
    targetThreat: "Synthetic Memories",
    description: "Every 90 min: touch 3 objects, state time/location aloud. Forces conscious override of automated/induced perception.",
    effectiveness: "★★★",
    type: "Behavioral"
  },
  {
    name: "Behavioral Jitter",
    targetThreat: "Predictive Analytics",
    description: "Randomized room changes/actions to break spatial Pattern-of-Life (POL) baselines used by Gotham/Digital Twins.",
    effectiveness: "★★★",
    type: "Behavioral"
  },
  {
    name: "Preference Entropy Audit",
    targetThreat: "Digital Twin Modeling",
    description: "Use local LLMs to generate contradictory profiles/traffic to poison the 'Digital Twin' model prediction.",
    effectiveness: "★★☆",
    type: "Behavioral"
  },
  {
    name: "GDPR Art. 22 Challenge",
    targetThreat: "Automated Decisions",
    description: "Legal challenge: Right to human intervention. Halted Watson Oncology deployment (Ligier v. IBM).",
    effectiveness: "★★☆",
    type: "Legal"
  },
  {
    name: "BIPA §15(b) Claim",
    targetThreat: "Unauthorized Biometrics",
    description: "Private right of action ($5k/violation). $650M Facebook settlement precedent.",
    effectiveness: "★★★",
    type: "Legal"
  },
  {
    name: "FCC Enforcement",
    targetThreat: "MAE Transmission",
    description: "File complaint for unlicensed ISM-band transmission (Kerr v. DoD precedent). Requires spectrum analyzer logs.",
    effectiveness: "★☆☆",
    type: "Legal"
  },
  {
    name: "Atmospheric Ionization Shield",
    targetThreat: "Directed Energy Weapons",
    description: "Create transient electromagnetic deflector shields using atmospheric ionization (BAE Systems method).",
    effectiveness: "★★☆",
    type: "Physical"
  }
];