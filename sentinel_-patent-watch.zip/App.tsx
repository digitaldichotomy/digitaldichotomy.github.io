import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Shield, 
  AlertTriangle,
  FileWarning,
  Lock,
  Database,
  EyeOff,
  Activity,
  ArrowUp,
  ArrowDown
} from 'lucide-react';
import { PATENTS_DATA, COUNTERMEASURES } from './constants';
import { Patent, ThreatLevel } from './types';
import { PatentModal } from './components/PatentModal';

type SortKey = keyof Patent;
interface SortConfig {
  key: SortKey;
  direction: 'asc' | 'desc';
}

const App: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPatent, setSelectedPatent] = useState<Patent | null>(null);
  const [sortConfig, setSortConfig] = useState<SortConfig>({ key: 'rank', direction: 'asc' });

  // Filter & Sort Logic
  const processedPatents = useMemo(() => {
    // 1. Filter
    let data = PATENTS_DATA.filter(p => {
      const s = searchTerm.toLowerCase();
      return (
        p.title.toLowerCase().includes(s) ||
        p.assignee.toLowerCase().includes(s) ||
        p.technicalDetail.toLowerCase().includes(s) ||
        p.id.toLowerCase().includes(s) ||
        p.alarmingReason.toLowerCase().includes(s) ||
        p.tier.toLowerCase().includes(s) ||
        p.category.toLowerCase().includes(s)
      );
    });

    // 2. Sort
    data.sort((a, b) => {
      const aValue = a[sortConfig.key];
      const bValue = b[sortConfig.key];

      // Custom weight for ThreatLevel to sort by severity instead of alphabet
      if (sortConfig.key === 'threatLevel') {
        const weights: Record<string, number> = {
          [ThreatLevel.CRITICAL]: 5,
          [ThreatLevel.HIGH]: 4,
          [ThreatLevel.MEDIUM]: 3,
          [ThreatLevel.LOW]: 2,
          [ThreatLevel.DEFENSE]: 1
        };
        const aWeight = weights[aValue as string] || 0;
        const bWeight = weights[bValue as string] || 0;
        
        if (aWeight < bWeight) return sortConfig.direction === 'asc' ? -1 : 1;
        if (aWeight > bWeight) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      }

      // Default string/number sort
      if (aValue < bValue) {
        return sortConfig.direction === 'asc' ? -1 : 1;
      }
      if (aValue > bValue) {
        return sortConfig.direction === 'asc' ? 1 : -1;
      }
      return 0;
    });

    return data;
  }, [searchTerm, sortConfig]);

  const handleSort = (key: SortKey) => {
    setSortConfig(current => ({
      key,
      direction: current.key === key && current.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const SortIcon = ({ column }: { column: SortKey }) => {
    if (sortConfig.key !== column) return <span className="w-3 h-3 ml-1 inline-block opacity-20">↕</span>;
    return sortConfig.direction === 'asc' 
      ? <ArrowUp size={10} className="ml-1 inline-block text-emerald-400" />
      : <ArrowDown size={10} className="ml-1 inline-block text-emerald-400" />;
  };

  return (
    <div className="min-h-screen bg-black text-slate-400 font-mono text-xs selection:bg-red-900/50 selection:text-red-100">
      
      {/* COMPACT HEADER */}
      <header className="border-b border-slate-800 bg-slate-950/80 sticky top-0 z-40 backdrop-blur-md">
        <div className="w-full px-4 h-10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Shield size={14} className="text-red-500 animate-pulse" />
            <h1 className="font-bold text-slate-100 tracking-tight">SENTINEL_DB <span className="text-red-600 text-[9px] align-top">LEAK_V2.5</span></h1>
            <div className="h-4 w-[1px] bg-slate-800 mx-2"></div>
            <div className="flex gap-4 text-[10px] text-slate-500 uppercase tracking-wider hidden md:flex">
              <span>Records: <b className="text-slate-300">{PATENTS_DATA.length}</b></span>
              <span>Defense: <b className="text-cyan-400">{PATENTS_DATA.filter(p => p.threatLevel === ThreatLevel.DEFENSE).length}</b></span>
              <span>Critical: <b className="text-red-500">{PATENTS_DATA.filter(p => p.threatLevel === ThreatLevel.CRITICAL).length}</b></span>
              <span className="text-red-500 animate-pulse font-bold">STATUS: COMPROMISED</span>
            </div>
          </div>
          
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded px-2 py-0.5 w-64">
             <Search size={10} className="text-slate-500 mr-2" />
             <input 
               type="text" 
               placeholder="QUERY DATABASE..." 
               className="bg-transparent border-none outline-none text-[10px] w-full text-slate-300 placeholder:text-slate-700 uppercase font-mono"
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
             />
          </div>
        </div>
      </header>

      <main className="w-full max-w-[1920px] mx-auto p-4 space-y-6">
        
        {/* PATENT TABLE */}
        <div className="border border-slate-800 bg-slate-900/20 rounded-sm overflow-hidden">
          <div className="bg-slate-950 px-3 py-1.5 border-b border-slate-800 flex justify-between items-center">
            <h2 className="text-[10px] font-bold text-slate-300 uppercase tracking-widest flex items-center gap-2">
              <Database size={12} className="text-red-500" /> Detected Surveillance Technologies & Countermeasures
            </h2>
            <div className="text-[9px] text-red-900 bg-red-950/30 px-1 border border-red-900/50 rounded">EYES ONLY</div>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-[9px] uppercase tracking-wider text-slate-500 bg-slate-900/80">
                  <th 
                    className="p-2 w-10 text-center text-slate-600 cursor-pointer hover:bg-slate-800/50 hover:text-slate-300 transition-colors select-none"
                    onClick={() => handleSort('rank')}
                  >
                    # <SortIcon column="rank" />
                  </th>
                  <th 
                    className="p-2 w-28 border-l border-slate-800/50 cursor-pointer hover:bg-slate-800/50 hover:text-slate-300 transition-colors select-none"
                    onClick={() => handleSort('id')}
                  >
                    Patent ID <SortIcon column="id" />
                  </th>
                  <th 
                    className="p-2 w-32 border-l border-slate-800/50 cursor-pointer hover:bg-slate-800/50 hover:text-slate-300 transition-colors select-none"
                    onClick={() => handleSort('tier')}
                  >
                    Tier / Category <SortIcon column="tier" />
                  </th>
                  <th 
                    className="p-2 w-32 border-l border-slate-800/50 cursor-pointer hover:bg-slate-800/50 hover:text-slate-300 transition-colors select-none"
                    onClick={() => handleSort('assignee')}
                  >
                    Assignee <SortIcon column="assignee" />
                  </th>
                  <th 
                    className="p-2 w-64 border-l border-slate-800/50 cursor-pointer hover:bg-slate-800/50 hover:text-slate-300 transition-colors select-none"
                    onClick={() => handleSort('title')}
                  >
                    System Title <SortIcon column="title" />
                  </th>
                  <th className="p-2 border-l border-slate-800/50">Functionality & Mechanism</th>
                  <th 
                    className="p-2 w-24 border-l border-slate-800/50 text-center cursor-pointer hover:bg-slate-800/50 hover:text-slate-300 transition-colors select-none"
                    onClick={() => handleSort('threatLevel')}
                  >
                    Level <SortIcon column="threatLevel" />
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/40 text-[11px]">
                {processedPatents.map((p) => {
                  const isDefense = p.threatLevel === ThreatLevel.DEFENSE;
                  return (
                    <tr 
                      key={p.id} 
                      onClick={() => setSelectedPatent(p)}
                      className={`cursor-pointer transition-colors group ${isDefense ? 'hover:bg-cyan-900/10' : 'hover:bg-red-500/10'}`}
                    >
                      <td className={`p-2 text-center text-slate-600 font-bold ${isDefense ? 'group-hover:text-cyan-400' : 'group-hover:text-red-500'}`}>{p.rank}</td>
                      <td className="p-2 font-mono text-slate-400 group-hover:text-slate-200 border-l border-slate-800/50">{p.id}</td>
                      <td className="p-2 text-slate-500 border-l border-slate-800/50 text-[10px] font-semibold">{p.tier}</td>
                      <td className={`p-2 font-bold border-l border-slate-800/50 ${isDefense ? 'text-cyan-500/80' : 'text-emerald-500/80'}`}>{p.assignee}</td>
                      <td className="p-2 text-slate-300 font-medium border-l border-slate-800/50">{p.title}</td>
                      <td className="p-2 text-slate-400 border-l border-slate-800/50 leading-snug">
                        {isDefense ? 
                          <span className="text-cyan-500 mr-1 opacity-0 group-hover:opacity-100 transition-opacity">🛡</span> :
                          <span className="text-red-500 mr-1 opacity-0 group-hover:opacity-100 transition-opacity">⚠</span>
                        }
                        {p.alarmingReason}
                        <span className="text-slate-600 ml-2 hidden group-hover:inline font-mono text-[10px]">[{p.technicalDetail}]</span>
                      </td>
                      <td className="p-2 border-l border-slate-800/50 text-center">
                        <span className={`px-1 rounded-[2px] text-[9px] font-bold border uppercase ${
                          p.threatLevel === ThreatLevel.CRITICAL ? 'bg-red-950/50 text-red-500 border-red-900/50' :
                          p.threatLevel === ThreatLevel.HIGH ? 'bg-orange-950/30 text-orange-500 border-orange-900/30' :
                          p.threatLevel === ThreatLevel.DEFENSE ? 'bg-cyan-950/30 text-cyan-400 border-cyan-900/30' :
                          'bg-slate-800 text-slate-500 border-slate-700'
                        }`}>
                          {p.threatLevel}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* COUNTERMEASURES TABLE - FULL WIDTH */}
        <div className="w-full">
          <div className="border border-slate-800 bg-slate-900/20 rounded-sm overflow-hidden">
             <div className="bg-slate-950 px-3 py-1.5 border-b border-slate-800 flex justify-between items-center">
              <h2 className="text-[10px] font-bold text-emerald-500 uppercase tracking-widest flex items-center gap-2">
                <Lock size={12} /> Active Defense Protocols
              </h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-[9px] uppercase tracking-wider text-slate-500 bg-slate-900/80">
                    <th className="p-2 w-48">Protocol</th>
                    <th className="p-2 w-48 border-l border-slate-800/50">Target Threat</th>
                    <th className="p-2 border-l border-slate-800/50">Mechanism</th>
                    <th className="p-2 w-24 border-l border-slate-800/50 text-center">Rating</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/40 text-[10px]">
                  {COUNTERMEASURES.map((cm, idx) => (
                    <tr key={idx} className="hover:bg-emerald-500/5 transition-colors">
                      <td className="p-2 text-emerald-400 font-bold">{cm.name}</td>
                      <td className="p-2 text-red-400/70 border-l border-slate-800/50">{cm.targetThreat}</td>
                      <td className="p-2 text-slate-400 border-l border-slate-800/50 leading-snug">{cm.description}</td>
                      <td className="p-2 text-yellow-500 font-mono text-[10px] border-l border-slate-800/50 text-center">{cm.effectiveness}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

      </main>

      {/* MODAL */}
      {selectedPatent && (
        <PatentModal 
          patent={selectedPatent} 
          onClose={() => setSelectedPatent(null)} 
        />
      )}
    </div>
  );
};

export default App;