import React, { useState, useEffect } from 'react';
import { X, ShieldAlert, Activity, Fingerprint, Cpu, Lock } from 'lucide-react';
import { Patent, ThreatLevel } from '../types';
import { analyzePatentRisk } from '../services/geminiService';

interface PatentModalProps {
  patent: Patent;
  onClose: () => void;
}

export const PatentModal: React.FC<PatentModalProps> = ({ patent, onClose }) => {
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Reset analysis when patent changes
    setAnalysis(null);
  }, [patent]);

  const handleRunAnalysis = async () => {
    setLoading(true);
    const result = await analyzePatentRisk(patent);
    setAnalysis(result);
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="bg-slate-900 border border-slate-600 w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-xl shadow-2xl relative flex flex-col">
        
        {/* Header */}
        <div className="p-6 border-b border-slate-700 bg-slate-900/90 sticky top-0 z-10 flex justify-between items-start">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-slate-400 mb-2">
              <span className="px-2 py-0.5 bg-slate-800 rounded border border-slate-700">{patent.id}</span>
              <span className="text-emerald-500">{patent.assignee}</span>
            </div>
            <h2 className="text-xl font-bold text-white leading-tight font-mono">{patent.title}</h2>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
            <X size={24} />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-6 flex-1">
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-red-900/10 border border-red-900/30 rounded-lg">
              <div className="flex items-center gap-2 text-red-400 mb-2 font-bold uppercase text-xs tracking-wider">
                <ShieldAlert size={16} /> Threat Level
              </div>
              <div className="text-2xl font-mono text-red-200">{patent.threatLevel}</div>
            </div>
            
            <div className="p-4 bg-slate-800/50 border border-slate-700 rounded-lg">
              <div className="flex items-center gap-2 text-emerald-400 mb-2 font-bold uppercase text-xs tracking-wider">
                <Activity size={16} /> Category
              </div>
              <div className="text-lg text-slate-200">{patent.category}</div>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-2">
              <Fingerprint size={16} /> Why It Is Alarming
            </h3>
            <p className="text-slate-400 leading-relaxed border-l-2 border-red-500 pl-4">
              {patent.alarmingReason}
            </p>
          </div>

          <div>
            <h3 className="text-sm font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-2">
              <Cpu size={16} /> Technical Specifics
            </h3>
            <p className="text-slate-400 font-mono text-sm bg-slate-950 p-3 rounded border border-slate-800">
              {patent.technicalDetail}
            </p>
          </div>

          {/* AI Analysis Section */}
          <div className="mt-8 pt-6 border-t border-slate-700">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-emerald-400 font-bold flex items-center gap-2">
                <Lock size={18} /> TACTICAL THREAT ASSESSMENT
              </h3>
              {!analysis && !loading && (
                <button 
                  onClick={handleRunAnalysis}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold uppercase tracking-wider rounded transition-all shadow-lg shadow-emerald-900/20"
                >
                  Initiate Analysis
                </button>
              )}
            </div>

            {loading && (
              <div className="flex flex-col items-center py-8 space-y-3">
                <div className="w-12 h-1 border-t border-emerald-500 animate-ping"></div>
                <div className="text-emerald-500 font-mono text-xs animate-pulse">DECRYPTING PROTOCOLS...</div>
              </div>
            )}

            {analysis && (
              <div className="bg-slate-950 border border-emerald-900/30 p-4 rounded text-sm text-slate-300 font-mono whitespace-pre-line leading-relaxed shadow-inner shadow-black/50">
                {analysis}
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};