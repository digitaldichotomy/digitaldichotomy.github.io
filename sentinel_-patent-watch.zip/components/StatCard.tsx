import React from 'react';

interface StatCardProps {
  label: string;
  value: string | number;
  trend?: 'up' | 'down' | 'neutral';
  color?: string;
}

export const StatCard: React.FC<StatCardProps> = ({ label, value, trend, color = "text-emerald-400" }) => {
  return (
    <div className="bg-slate-800/50 border border-slate-700 p-4 rounded-lg backdrop-blur-sm">
      <div className="text-xs text-slate-400 uppercase tracking-wider mb-1 font-mono">{label}</div>
      <div className={`text-2xl font-bold ${color} font-mono flex items-center gap-2`}>
        {value}
        {trend === 'up' && <span className="text-xs text-red-400">▲</span>}
        {trend === 'down' && <span className="text-xs text-emerald-400">▼</span>}
      </div>
    </div>
  );
};
